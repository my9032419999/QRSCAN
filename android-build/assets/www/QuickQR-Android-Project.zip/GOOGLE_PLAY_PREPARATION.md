# Google Play Store Preparation Guide

## App Information
- **Title**: QuickQR – QR & Barcode Scanner
- **Short Description**: Scan QR codes and barcodes fast. Create, save and share QR codes easily.
- **Category**: Tools / Productivity
- **Content Rating**: Everyone (PEGI 3)

## Data Safety Declaration
- **Data Collected**: None by the app core.
- **Offline First**: All scans and generated QR codes are stored locally in the on-device Room SQLite database.
- **Third-Party SDKs**: Google Mobile Ads SDK (AdMob) processes advertising IDs and crash diagnostic metrics in accordance with Google Play developer policies.

## Google Play Subscriptions (Pro Mode Monthly Auto-Renewing)
- **Product ID**: `quickqr_pro_monthly`
- **Product Type**: Auto-renewing subscription (`BillingClient.ProductType.SUBS`)
- **Billing Period**: Monthly (1 month recurring)
- **Auto Location & Currency Pricing**:
  - **India**: ₹149.00 INR / month (Base Plan ID: `monthly-inr`)
  - **United States & Global**: $5.00 USD / month (Base Plan ID: `monthly-usd`)
  - **Eurozone**: €4.99 EUR / month (Base Plan ID: `monthly-eur`)
  - **United Kingdom**: £4.49 GBP / month (Base Plan ID: `monthly-gbp`)
  - Google Play Store automatically detects the user's localized billing account country, presents their native currency symbol, and applies local taxes automatically.
- **Benefits**:
  - Complete AdMob ads removal (no banner ads, no interstitial ads)
  - Unlimited continuous batch scanning
  - High-resolution 4K and SVG QR code exports with custom logos
- **Google Play Billing Library**: v7.1.1 (`com.android.billingclient:billing-ktx:7.1.1`)
- **Play Console Setup**:
  1. Open Google Play Console > **Monetize with Play** > **Subscriptions**.
  2. Click **Create subscription**.
  3. Enter Product ID: `quickqr_pro_monthly`.
  4. Name: `QuickQR Pro Monthly Ad-Free`.
  5. Description: `Unlock 100% ad-free experience, unlimited batch scanning, and 4K exports.`.
  6. Add Base Plan: Monthly Auto-Renewing. Set regional pricing: ₹149 in India, $5.00 in US/Global.
  7. Activate the base plan and subscription!

## Feature Graphic Specs
- **Dimensions**: 1024 x 500 px PNG/JPEG
- **Theme**: Blue (#0877ED) to Cyan (#00B8D9) gradient with glowing scanner brackets, white QR code, and "QuickQR - Scan Fast. Create Easy." tagline.
