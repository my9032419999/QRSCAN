package com.jagadeesh.quickqr

import android.app.Application
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration

/**
 * QuickQR Application Entry Point
 * Designed by Jagadeesh
 */
class QuickQRApp : Application() {
    override fun onCreate() {
        super.onCreate()
        
        // Initialize Google Mobile Ads SDK with test device configuration
        MobileAds.initialize(this) {
            // Initialization complete
        }

        // Set test device ID configuration for development safety
        val configuration = RequestConfiguration.Builder()
            .setTestDeviceIds(listOf(RequestConfiguration.DEVICE_ID_EMULATOR))
            .build()
        MobileAds.setRequestConfiguration(configuration)
    }
}
