package com.jagadeesh.quickqr.generator

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.util.EnumMap

object QrCodeGenerator {
    /**
     * Generates a high-quality QR code Bitmap locally with custom colors and error correction
     */
    fun generateQrBitmap(
        content: String,
        width: Int = 800,
        height: Int = 800,
        foregroundColor: Int = Color.parseColor("#0877ED"),
        backgroundColor: Int = Color.WHITE,
        errorCorrection: ErrorCorrectionLevel = ErrorCorrectionLevel.H,
        centerLogo: Bitmap? = null
    ): Bitmap {
        val hints = EnumMap<EncodeHintType, Any>(EncodeHintType::class.java).apply {
            put(EncodeHintType.CHARACTER_SET, "UTF-8")
            put(EncodeHintType.MARGIN, 2)
            put(EncodeHintType.ERROR_CORRECTION, errorCorrection)
        }

        val writer = QRCodeWriter()
        val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, width, height, hints)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        for (x in 0 until width) {
            for (y in 0 until height) {
                bitmap.setPixel(x, y, if (bitMatrix.get(x, y)) foregroundColor else backgroundColor)
            }
        }

        // Overlay center logo safely if provided
        centerLogo?.let { logo ->
            val canvas = Canvas(bitmap)
            val logoSize = (width * 0.22f).toInt()
            val scaledLogo = Bitmap.createScaledBitmap(logo, logoSize, logoSize, true)
            val left = (width - logoSize) / 2f
            val top = (height - logoSize) / 2f
            canvas.drawBitmap(scaledLogo, left, top, null)
        }

        return bitmap
    }
}
