package com.jagadeesh.quickqr.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ScanDao {
    @Query("SELECT * FROM scan_results ORDER BY timestamp DESC")
    fun getAllScans(): Flow<List<ScanResultEntity>>

    @Query("SELECT * FROM scan_results ORDER BY timestamp DESC LIMIT 10")
    fun getRecentScans(): Flow<List<ScanResultEntity>>

    @Query("SELECT * FROM scan_results WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavorites(): Flow<List<ScanResultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScan(scan: ScanResultEntity): Long

    @Update
    suspend fun updateScan(scan: ScanResultEntity)

    @Delete
    suspend fun deleteScan(scan: ScanResultEntity)

    @Query("DELETE FROM scan_results")
    suspend fun clearAll()
}
