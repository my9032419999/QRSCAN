package com.jagadeesh.quickqr.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ScanResultEntity::class, SavedQrEntity::class], version = 1, exportSchema = false)
abstract class QuickQRDatabase : RoomDatabase() {
    abstract fun scanDao(): ScanDao
    abstract fun savedQrDao(): SavedQrDao

    companion object {
        @Volatile
        private var INSTANCE: QuickQRDatabase? = null

        fun getDatabase(context: Context): QuickQRDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    QuickQRDatabase::class.java,
                    "quickqr_database.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
