package com.jagadeesh.quickqr.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_qr_codes")
data class SavedQrEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val type: String,
    val foregroundColor: Int,
    val backgroundColor: Int,
    val errorCorrection: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)
