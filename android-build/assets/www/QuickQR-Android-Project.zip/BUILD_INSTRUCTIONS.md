# QuickQR – Android Studio Build Instructions

Designed by Jagadeesh
Application Name: QuickQR – QR & Barcode Scanner

## Prerequisites
1. **Android Studio**: Android Studio Ladybug (2024.2.1) or newer.
2. **JDK**: Java Development Kit 17 or 21.
3. **Android SDK**: Android SDK 35 (API 35), Min SDK 26 (Android 8.0).

## Opening the Project
1. Extract or clone this repository.
2. Open Android Studio.
3. Click **Open** and select the root directory containing `settings.gradle.kts`.
4. Allow Gradle sync to download dependencies (CameraX, ML Kit, ZXing, Room, Material 3, Play Services Ads).

## Running in Debug Mode
1. Connect an Android phone with USB debugging enabled, or launch an Android Virtual Device (AVD).
2. Select the `app` run configuration.
3. Click the green **Run** button (Shift + F10).

## Building a Release APK
1. In Android Studio, go to **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
2. The generated APK will be in `app/build/outputs/apk/release/app-release-unsigned.apk`.

## Building a Signed Android App Bundle (AAB) for Google Play
1. Go to **Build** > **Generate Signed Bundle / APK...**.
2. Select **Android App Bundle** and click Next.
3. Create or specify your Key store path, keystore password, key alias, and key password.
4. Select build variant `release` and click **Create**.
5. The signed `.aab` bundle will be generated under `app/release/app-release.aab`, ready for Google Play Console upload!
